import numpy as np
# import matplotlib.pyplot as plt
# import readlist
def readtxt():
    #读取文件，返回labeler_id,image_id,label_list的列表
    labeler_list = []
    image_list = []
    label_list = []
    f = open(r"imgdata.txt")
    file = f.read()
    line = file.split("\n")
    for item in line:
        if item != '':
            index = item.split(' ')
            labeler_id = index[1]
            image_id = index[0]
            label = int(index[2])
            labeler_list.append(labeler_id)
            image_list.append(image_id)
            label_list.append(label)
    # labeler_unique_id = np.unique(labeler_list)
    # num_labeler = len(labeler_unique_id)
    num_image = len(image_list)
    num_label = len(label_list)
    image_labeler_label = {}
    for i in range(num_image):
        if image_list[i] not in image_labeler_label.keys():
            image_labeler_label[image_list[i]] = {}
        if labeler_list[i] not in image_labeler_label[image_list[i]]:
            image_labeler_label[image_list[i]][labeler_list[i]] = label_list[i]




    return labeler_list,label_list,image_list,image_labeler_label

if __name__ == '__main__':
    print(readtxt())