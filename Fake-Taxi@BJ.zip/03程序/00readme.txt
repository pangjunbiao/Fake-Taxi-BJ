glad.py----主函数（111-113行分别对应论文中的GLADTL、GLADT和GLAD）
em_notorch.py----GLADTL函数，小论文中EIBP
em_notorch_1.py-----GLADT函数
em_oldplan.py----GLAD函数
