import torch
import copy
import numpy as np

def fun(x):
    temp = torch.sigmoid(x)
    # if temp == 1.0:
    #     temp-= 0.00001
    # if temp== 0:
    #     temp += 0.00001
    return temp

# def pfun(pr_z,x,y,num_image,num_labeler,label_arr):
#     p_z = copy.copy(pr_z)
#     a = copy.copy(x)
#     b = copy.copy(y)
#     for j in range(num_image):
#         for i in range(num_labeler):
#             if label_arr[j][i]==0:
#                 p_z[0][j] *= np.




def Qfun(pr_z,num_image,num_labeler,label_arr,alpha_arr,beta_arr):
    sum_n = 0#常数项目
    sum_ch = 0#变量项
    for j in range(num_image):
        if (pr_z[1][j] == 0) or (pr_z[0][j] == 0):
            sum_n += 1
        else:
            temp = pr_z[0][j]*torch.log(pr_z[0][j])+pr_z[1][j]*torch.log(pr_z[1][j])
            sum_n+=temp
    for j in range(num_image):
        for i in range(num_labeler):
            # print(torch.sigmoid(alpha_arr[i]+beta_arr[j]))
            a = pr_z[1][j]*(label_arr[j][i]*torch.log(torch.sigmoid(alpha_arr[i]*beta_arr[j]))+(1-label_arr[j][i])*(torch.log(1-fun(alpha_arr[i]*beta_arr[j]))))
            b = pr_z[0][j]*((1-label_arr[j][i])*torch.log(fun(alpha_arr[i]*beta_arr[j]))+label_arr[j][i]*(torch.log(1-fun(alpha_arr[i]*beta_arr[j]))))
            sum_ch += (a+b)
    return sum_ch+sum_n

def em(label_arr,num_image,num_labeler,pr_Z,pr_Alpha,pr_Beta):
    label_arr = torch.tensor(label_arr)
    pr_Alpha.requires_grad = True#先验概率alpha，后更新alpha
    pr_Beta.requires_grad = True#先验Beta，后更新Beta
    pr_Z = torch.tensor(pr_Z)#先验Z
    rate = 0.001#学习率
    opitmizer = torch.optim.SGD((pr_Alpha,pr_Beta),lr=rate)
    for ephc in range(1000):
        print(pr_Beta)
        Q = Qfun(pr_Z,num_image,num_labeler,label_arr,alpha_arr=pr_Alpha,beta_arr=pr_Beta)
        opitmizer.zero_grad()#清零梯度
        Q.backward()
        opitmizer.step()
        print(pr_Beta.grad.data)
        print(ephc)
    pr_Z_new = [[],[]]
    for j in range(num_image):#更新p_z
        p_1 = 0
        p_0 = 0
        sum_p = 0
        for i in range(num_labeler):
            if label_arr[j][i] == 0:
                p_0 += torch.sigmoid(pr_Alpha[i]*pr_Beta[j])
                sum_p += torch.sigmoid(pr_Alpha[i]*pr_Beta[j])
            else:
                p_1 += torch.sigmoid(pr_Alpha[i]*pr_Beta[j])
                sum_p += torch.sigmoid(pr_Alpha[i]*pr_Beta[j])
        pr_Z_new[0].append(p_0/sum_p)
        pr_Z_new[1].append(p_1/sum_p)
    pr_Z = pr_Z_new


    return pr_Z,pr_Alpha,pr_Beta





