import numpy as np
import read_True
import read_data
import em_oldplan
import em_notorch
import em_notorch_1
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve

plt.rcParams['font.sans-serif'] = ['SimHei']
def getp_Z(p_z,num_img):
        p_Z = np.zeros(num_img)
        for j in range(num_img):
                if p_z[0][j] == -1:
                        p_Z[j] = -1
                        continue
                if p_z[0][j]>p_z[1][j]:
                        p_Z[j] = 0
                else:
                        p_Z[j] = 1
        return p_Z


def get_accuracy(p_z, image_label_T):
    sum_pz = 0
    true_pr = 0
    for i in range(1999, len(p_z)):  # 读取的文件
        if (i in image_label_T.keys()) and (p_z[i] != -1):
            sum_pz += 1
            if p_z[i] == image_label_T[i]:
                true_pr += 1
    return true_pr / sum_pz
def get_accuracy_o(p_z,image_label_T,P_Z):
        sum_pz = 0
        true_pr = 0
        pre_iabel_list=[]
        true_label=[]
        for i in range(1999, len(p_z)):  # 读取的文件
                if (i in image_label_T.keys())and (p_z[i] != -1):
                        sum_pz += 1
                        pre_iabel_list.append(P_Z[i])
                        true_label.append(image_label_T[i])
                        if p_z[i] == image_label_T[i]:
                                true_pr +=1
        return true_pr/sum_pz,pre_iabel_list,true_label

def get_ROC(p_z, image_label_T):
    sum_pz = 0
    TP=0
    TN=0
    FP=0
    FN=0
    for i in range(0, len(p_z)):  # 读取的文件
        if (i in image_label_T.keys()) and (p_z[i] != -1):
            sum_pz += 1
            if p_z[i] == image_label_T[i]:
                if p_z[i]==1:
                    TP += 1
                else:
                    TN += 1
            else:
                if p_z[i] == 1:
                    FP += 1
                else:
                    FN +=1
    return TP,TN,FP,FN

#一千张图，20个不同标注者的结果。
labeler_list,label_list,image_list,image_labeler_label = read_data.readtxt()
image_list_T,label_list_T,image_label_T = read_True.read_T()
labeler_uni = np.unique(labeler_list)
label_arr = np.zeros(())
num_labeler =len(np.unique(labeler_list))
num_image = 2163
label_arr = np.zeros((num_image,num_labeler))+2
for i in range(len(labeler_list)):
        temp_labeler_id = labeler_list[i]
        for j in range(num_labeler):
                if labeler_uni[j] == temp_labeler_id:
                        image_int = int(image_list[i])
                        label_arr[image_int][j] = image_labeler_label[image_list[i]][labeler_uni[j]]
                        break
b =0
for temp in label_arr:
        for item in temp:
                if item<2:
                        b +=1
# num_image = 2162
# num_labeler = 20
p_z = [[],[]]
pr_alpha = []
pr_beta = []
for j in range(num_image):
        sum_P = 0
        num_labeler_image = 0
        for i in range(num_labeler):
                if label_arr[j][i] < 2:
                        sum_P += label_arr[j][i]
                        num_labeler_image += 1
        if num_labeler_image == 0:
                p_z[0].append(-1)
                p_z[1].append(-1)
                continue
        p_temp = sum_P/num_labeler_image
        p_z[0].append(1-p_temp)
        p_z[1].append(p_temp)
p_z = np.array(p_z)
pre_p_Z = getp_Z(p_z,num_image)
pr_alpha = np.ones(num_labeler)
pr_beta = np.ones(num_image)
p_z1, alpha1, beta1,time_r1 = em_notorch.em(label_arr, num_image, num_labeler, p_z, pr_alpha, pr_beta,image_label_T)#含时间的lowrank对应em_notorch
p_z2, alpha2, beta2,time_r2 = em_notorch_1.em(label_arr, num_image, num_labeler, p_z, pr_alpha, pr_beta,image_label_T)#含时间的GLAD对应em_notorch_1
p_z3, alpha3, beta3 = em_oldplan.em(label_arr, num_image, num_labeler, p_z, pr_alpha, pr_beta,image_label_T)#岳宇方法对应em_oldplan
plt.xlabel("Echo")
plt.ylabel("Accuracy")
plt.rcParams['font.sans-serif']=['SimHei']
plt.legend()
plt.show()

# new_p_Z = getp_Z(p_z,num_image)
# num = 0
# diff_list_clone = []
# diff_list=[]
# diff_list_noclone = []
# for i in range(num_image):
#         if pre_p_Z[i] != new_p_Z[i]:
#                 diff_list.append(i)
#                 num += 1
# # print(alpha)
# # print(beta)
# # # print(diff_list)
# print(num)
# # print(pre_p_Z)
# # print(new_p_Z)
# # fw = open("query_deal.txt", 'w')
# # for i in range(1999,len(pre_p_Z)):
# #         a = str(pre_p_Z[i])+" "+str(new_p_Z[i])
# #         fw.write(a)   # 将字符串写入文件中
# #         fw.write("\n")    # 换行
# o_accure,pre_label,true_label = get_accuracy_o(pre_p_Z,image_label_T,p_z[1])
# fpr,tpr,threshold = roc_curve(true_label,pre_label,pos_label=1)#返回ROC曲线
# 返回ROC参数
TP, TN, FP, FN = get_ROC(pre_p_Z, image_label_T,)
print("TP:", TP, "TN:", TN, "FP:", FP, "FN:", FN)

# plt.plot(fpr,tpr,label="投票算法",color="y")
# plt.xlabel("FPR")
# plt.ylabel("TPR")
# plt.legend()
# plt.show()
# n_accure = get_accuracy(p_z1,image_label_T)
# print(o_accure)
# print(n_accure)
