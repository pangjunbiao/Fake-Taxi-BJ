import copy
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve

#含有低秩约束的模型
def getp_Z(p_z, num_img):
    p_Z = np.zeros(num_img)
    for j in range(num_img):
        if p_z[0][j] == -1:
            p_Z[j] = -1
            continue
        if p_z[0][j] > p_z[1][j]:
            p_Z[j] = 0
        else:
            p_Z[j] = 1
    return p_Z

def get_label(p_z, image_label_T,P_Z):
    pre_iabel_list = []
    true_label = []
    for i in range(2000, len(p_z)):  # 读取的文件
        if (i in image_label_T.keys()) and (p_z[i] != -1):
            pre_iabel_list.append(P_Z[i])
            true_label.append(image_label_T[i])
    return pre_iabel_list,true_label

def get_accuracy(p_z, image_label_T):
    sum_pz = 0
    true_pr = 0
    for i in range(2000, len(p_z)):  # 读取的文件
        if (i in image_label_T.keys()) and (p_z[i] != -1):
            sum_pz += 1
            if p_z[i] == image_label_T[i]:
                true_pr += 1
    return true_pr / sum_pz

def get_ROC(p_z, image_label_T):
    sum_pz = 0
    TP=0
    TN=0
    FP=0
    FN=0
    for i in range(0, len(p_z)):  # 读取的文件
        if (i in image_label_T.keys()) and (p_z[i] != -1):
            sum_pz += 1
            if p_z[i] == image_label_T[i]:
                if p_z[i]==1:
                    TP += 1
                else:
                    TN += 1
            else:
                if p_z[i] == 1:
                    FP += 1
                else:
                    FN +=1
    return TP,TN,FP,FN

def softmax(x,t):
    # t 为阈值
    # x 为输入的矩阵
    if np.size(x) == 1:
        temp = x
        if abs(temp) > 1/(t):
            if temp > 0:
                temp = temp-1/(t)

            if temp < 0:
                temp = temp+1/(t)
        else:
            temp = 0
        return temp
    if np.size(x) > 1 and np.size(x)<65:
        a = []
        for temp in x:
            if abs(temp) > 1 / (1 * t):
                if temp >= 0:
                    temp = float(temp) - 1 / (1 * t)

                if temp < 0:
                    temp = float(temp) + 1 / (1 * t)
            else:
                temp = 0
            a.append(temp)
        return a
    else:
        a = np.zeros(x.shape)
        i = -1
        for temp_line in x :
            i += 1
            j =- 1
            for temp in temp_line:
                j += 1
                if abs(temp) > 1/(1*t):
                    if temp > 0:
                        temp = float(temp)-1/(1*t)

                    if temp < 0:
                        temp = float(temp)+1/(1*t)
                else:
                    temp = 0
                a[i][j] = temp
        return a

def fsvd(U,sigma,VT,a):
    #输入的U，VT；变化后的sigma，原来矩阵a
    M = np.shape(a)
    zero = np.zeros((M[0],M[1]-np.shape(sigma)[0]))
    diag_m = np.diag(sigma)
    # if sigma[0] == 0:
    #     diag_m  = np.array([[sigma[0],0],[0,0]])
    sigma = np.c_[diag_m,zero]
    k = np.dot(U,sigma)
    h = np.dot(k,VT)
    num = 0
    w = 0
    for j in h:
        for i in j:
            if i > 0 :
                # print(num,i)
                w +=1
            num += 1
    return h

def func(x):
    temp = 1/(1+np.exp(-x))
    return temp

def pfun(pr_z, x, y, num_image, num_labeler, label_arr,time_r):
    # x为输入的alpha，y为输入的beta
    p_z = copy.copy(pr_z)
    a = copy.copy(x)
    b = copy.copy(y)
    for j in range(num_image):
        if pr_z[0][j] == -1:
            p_z[0][j] = -1
            p_z[1][j] = -1
            continue
        sum_p = 0
        index = j%3
        for i in range(num_labeler):
            if label_arr[j][i] == 0:
                p_z[0][j] += pr_z[0][j]*func((a[i]+time_r[index][i])*b[j])
            if label_arr[j][i] == 1:
                p_z[1][j] += pr_z[1][j]*func((a[i]+time_r[index][i])*b[j])
        sum_p = p_z[0][j]+p_z[1][j]
        p_z[0][j] = p_z[0][j]/sum_p
        p_z[1][j] = p_z[1][j]/sum_p
    p_z = np.array(p_z)
    return p_z

def getT(gamma,E,labmda,mu):
    mid = gamma+E
    #进行SVD分解
    try:
        U, sigma, VT = np.linalg.svd(mid)
    except:
        print(mid)
    sigma = softmax(sigma,mu/labmda)
    T = fsvd(U,sigma,VT,mid)
    return T

def getE(T,gamma,mu):
    mid = T-gamma
    E = softmax(mid,mu)
    return E

def getgamma(T,E,L_r,mu):
    gamma = -T+E+L_r/mu
    return gamma

# 原函数
def Qfun(pr_z, num_image, num_labeler, label_arr, alpha_arr, beta_arr):
    sum_n = 0# 常数项目
    sum_ch = 0# 变量项
    for j in range(num_image):
        if (pr_z[1][j] == 0) or (pr_z[0][j] == 0):
            sum_n += 1
        else:
            temp = pr_z[0][j]*np.log(pr_z[0][j])+pr_z[1][j]*np.log(pr_z[1][j])
            sum_n+=temp
    for j in range(num_image):
        for i in range(num_labeler):
            # print(torch.sigmoid(alpha_arr[i]+beta_arr[j]))
            a = pr_z[1][j]*(label_arr[j][i]*np.log(func(alpha_arr[i]*beta_arr[j]))+(1-label_arr[j][i])*(np.log(1-func(alpha_arr[i]*beta_arr[j]))))
            b = pr_z[0][j]*((1-label_arr[j][i])*np.log(func(alpha_arr[i]*beta_arr[j]))+label_arr[j][i]*(np.log(1-func(alpha_arr[i]*beta_arr[j]))))
            sum_ch += (a+b)

    return sum_ch+sum_n

# time_r求导
def gettime_r(p_z,label_arr,num_image,num_labeler,alpha,beta,time_r):
    time_grad = np.zeros((3,num_labeler))
    for i in range(num_labeler):
        for j in range(num_image):
            if label_arr[j][i] == 2:
                continue
            index = i % 3
            time_grad[index][i] += (p_z[1][j] * label_arr[j][i] + p_z[0][j] * (1 - label_arr[j][i]) - func((alpha[i] + time_r[index][i]) * beta[j])) * beta[j]
    return time_grad

# alpha求导
def getalpha(p_z,label_arr,num_image,num_labeler,alpha,beta,time_r):
    a_grad = []
    index = 0
    for i in range(num_labeler):
        temp_1 = 0
        for j in range(num_image):
            if label_arr[j][i] == 2:
                continue
            index = j % 3
            temp_1 += (p_z[1][j]*label_arr[j][i]+p_z[0][j]*(1-label_arr[j][i])-func((alpha[i]+time_r[index][i])*beta[j]))*beta[j]
        a_grad.append(temp_1)
    return np.array(a_grad)

# beta求导
def getbeta(p_z,label_arr,num_image,num_labeler,alpha,beta,time_r):
    b_grad = []
    for j in range(num_image):
        temp_1 = 0
        for i in range(num_labeler):
            if label_arr[j][i] == 2:
                continue
            index = j%3
            temp_1 += (p_z[1][j]*label_arr[j][i]+p_z[0][j]*(1-label_arr[j][i])-func((alpha[i]+time_r[index][i])*beta[j]))*alpha[i]
        b_grad.append(temp_1)
    b_grad = np.array(b_grad)
    return b_grad

def em(label_arr,num_image,num_labeler,p_Z,pr_Alpha,pr_Beta,image_label_T):
    pr_p_z = np.array(p_Z)
    # label_arr[num_image][num_label]
    # num_image图像数量，num——labeler标记者数量，pr_z[2][num_image]每张图片是01的先验概率，pr_Alpha[num_labeler],pr_beta[num_image]
    time_r = np.ones((3,num_labeler))
    p_Z = pfun(p_Z,pr_Alpha,pr_Beta,num_image,num_labeler,label_arr,time_r)
    # time_r = np.array([0,0,0])
    rate = 0.0001
    lambda_ = 10
    mu = 70
    E = np.zeros(time_r.shape)
    # print(pr_p_z)
    accure_list = [0.68]
    ephc_list = [0]
    max_accure = 0
    m_Alpha = 0
    m_Beta = 0
    m_time_r = 0

    for ephc in range(200):
        Beta_gard = getbeta(p_Z,label_arr,num_image,num_labeler,pr_Alpha,pr_Beta,time_r)
        Alpha_gard = getalpha(p_Z,label_arr,num_image,num_labeler,pr_Alpha,pr_Beta,time_r)
        time_r = time_r +rate*gettime_r(p_Z,label_arr,num_image,num_labeler,pr_Alpha,pr_Beta,time_r)
        # L_r = gettime_r(p_Z,label_arr,num_image,num_labeler,pr_Alpha,pr_Beta,time_r)
        if ephc > 50 :
            L_r = time_r + rate * gettime_r(p_Z, label_arr, num_image, num_labeler, pr_Alpha, pr_Beta, time_r)
            T = getT(time_r,E,lambda_,mu)
            # print(T)
            E = getE(T,time_r,mu)
            time_r = getgamma(T,E,L_r,mu)
        pr_Alpha = pr_Alpha + rate*Alpha_gard
        pr_Beta = pr_Beta + rate*Beta_gard
        # time_r = time_r +3*rate*time_gard
        p_Z = pfun(p_Z,pr_Alpha,pr_Beta,num_image,num_labeler,label_arr,time_r)
        new_p_z = getp_Z(p_Z,num_image)
        n_accure = get_accuracy(new_p_z, image_label_T)
        if max_accure < n_accure:
            m_Alpha = pr_Alpha
            m_Beta = pr_Beta
            m_time_r = time_r
            m_p_z = p_Z
            max_accure = n_accure
        accure_list.append(n_accure)
        ephc_list.append(ephc+1)
    print(max_accure)
    # # 计算ROC曲线参数
    TP,TN,FP,FN = get_ROC(new_p_z, image_label_T)
    print("GLAD_TL:TP:",TP,"TN:",TN,"FP:",FP,"FN:",FN)

    # # 绘制精度曲线
    accure_arr = np.array(accure_list)
    ephc_arr = np.array(ephc_list)
    plt.plot(ephc_arr,accure_arr,label="GLAD_TL",color="red")
    print("GLAD_TL",n_accure)
    # plt.show()

    #绘制ROC曲线
    # pre_label,true_label = get_label(new_p_z, image_label_T,p_Z[1])
    # fpr, tpr, threshold = roc_curve(true_label, pre_label, pos_label=1)  # 返回ROC曲线
    # plt.plot(fpr, tpr, label="GLADTL", color="r")

    return m_p_z , m_Alpha , m_Beta,m_time_r





