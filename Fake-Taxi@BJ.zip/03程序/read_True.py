def read_T():
    f = open(r"imggth.txt")
    file = f.read()
    line = file.split("\n")

    image_list = []
    label_list = []
    image_label = {}
    for item in line:
        if item != '':
            index = item.split('\t')
            label = int(index[1])
            image_id = index[0]
            image_list.append(image_id)
            label_list.append(label)
            image_label[int(image_id)] = label
    return image_list,label_list,image_label

if __name__ == '__main__':
    image_list,label_list ,image_label= read_T()
    print()