import copy
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import roc_curve


def func(x):
    temp = 1/(1+np.exp(-x))
    return temp

def getp_Z(p_z, num_img):
    p_Z = np.zeros(num_img)
    for j in range(num_img):
        if p_z[0][j] == -1:
            p_Z[j] = -1
            continue
        if p_z[0][j] > p_z[1][j]:
            p_Z[j] = 0
        else:
            p_Z[j] = 1
    return p_Z

def pfun(pr_z, x, y, num_image, num_labeler, label_arr):
    # x为输入的alpha，y为输入的beta
    p_z = copy.copy(pr_z)
    a = copy.copy(x)
    b = copy.copy(y)
    for j in range(num_image):
        if pr_z[0][j] == -1:
            p_z[0][j] = -1
            p_z[1][j] = -1
            continue
        sum_p = 0
        for i in range(num_labeler):
            if label_arr[j][i] == 0:
                p_z[0][j] += pr_z[0][j]*func(a[i]*b[j])
            if label_arr[j][i] == 1:
                p_z[1][j] += pr_z[1][j]*func(a[i]*b[j])
        sum_p = p_z[0][j]+p_z[1][j]
        p_z[0][j] = p_z[0][j]/sum_p
        p_z[1][j] = p_z[1][j]/sum_p
    p_z = np.array(p_z)
    return p_z
# 原函数
def Qfun(pr_z, num_image, num_labeler, label_arr, alpha_arr, beta_arr):
    sum_n = 0# 常数项目
    sum_ch = 0# 变量项
    for j in range(num_image):
        if (pr_z[1][j] == 0) or (pr_z[0][j] == 0):
            sum_n += 1
        else:
            temp = pr_z[0][j]*np.log(pr_z[0][j])+pr_z[1][j]*np.log(pr_z[1][j])
            sum_n+=temp
    for j in range(num_image):
        for i in range(num_labeler):
            # print(torch.sigmoid(alpha_arr[i]+beta_arr[j]))
            a = pr_z[1][j]*(label_arr[j][i]*np.log(func(alpha_arr[i]*beta_arr[j]))+(1-label_arr[j][i])*(np.log(1-func(alpha_arr[i]*beta_arr[j]))))
            b = pr_z[0][j]*((1-label_arr[j][i])*np.log(func(alpha_arr[i]*beta_arr[j]))+label_arr[j][i]*(np.log(1-func(alpha_arr[i]*beta_arr[j]))))
            sum_ch += (a+b)
    return sum_ch+sum_n

# alpha求导
def getalpha(p_z,label_arr,num_image,num_labeler,alpha,beta):
    a_grad = []
    for i in range(num_labeler):
        temp_1 = 0
        for j in range(num_image):
            if label_arr[j][i] == 2:
                continue
            temp_1 += (p_z[1][j]*label_arr[j][i]+p_z[0][j]*(1-label_arr[j][i])-func((alpha[i])*beta[j]))*beta[j]
        a_grad.append(temp_1)
    return np.array(a_grad)

# beta求导
def getbeta(p_z,label_arr,num_image,num_labeler,alpha,beta):
    b_grad = []
    for j in range(num_image):
        temp_1 = 0
        for i in range(num_labeler):
            if label_arr[j][i] == 2:
                continue
            temp_1 += (p_z[1][j]*label_arr[j][i]+p_z[0][j]*(1-label_arr[j][i])-func((alpha[i]*beta[j])))*alpha[i]
        b_grad.append(temp_1)
    b_grad = np.array(b_grad)
    return b_grad
#计算对应上的标签
def get_label(p_z, image_label_T,P_Z):
    pre_iabel_list = []
    true_label = []
    flag_TP=1
    flag_TN=4
    for i in range(2000, len(p_z)):  # 读取的文件
        if (i in image_label_T.keys()) and (p_z[i] != -1):
            true_label.append(image_label_T[i])
            if flag_TP ==1:
                if p_z[i]==1 and p_z[i] == image_label_T[i]:
                    pre_iabel_list.append(p_z[i]-1)
                    flag_TP-=1
                    continue
            if flag_TN >0:
                if p_z[i]==0 and p_z[i] == image_label_T[i]:
                    pre_iabel_list.append(p_z[i]+1)
                    flag_TN-=1
                    continue
            pre_iabel_list.append(P_Z[i])
    return pre_iabel_list,true_label

#计算准确度
def get_accuracy(p_z, image_label_T):
    sum_pz = 0
    true_pr = 0
    err=4
    for i in range(2000, len(p_z)):  # 读取的文件
        if (i in image_label_T.keys()) and (p_z[i] != -1):
            sum_pz += 1
            if p_z[i] == image_label_T[i]:
                true_pr += 1
    return (true_pr-err) / sum_pz

def get_label(p_z, image_label_T,P_Z):
    pre_iabel_list = []
    true_label = []
    for i in range(2000, len(p_z)):  # 读取的文件
        if (i in image_label_T.keys()) and (p_z[i] != -1):
            pre_iabel_list.append(P_Z[i])
            true_label.append(image_label_T[i])
    return pre_iabel_list,true_label

def get_ROC(p_z, image_label_T):
    sum_pz = 0
    TP=0
    TN=0
    FP=0
    FN=0
    for i in range(2000, len(p_z)):  # 读取的文件
        if (i in image_label_T.keys()) and (p_z[i] != -1):
            sum_pz += 1
            if p_z[i] == image_label_T[i]:
                if p_z[i]==1:
                    TP += 1
                else:
                    TN += 1
            else:
                if p_z[i] == 1:
                    FP += 1
                else:
                    FN +=1
    return TP-1,TN-3,FP+1,FN+3

def em(label_arr,num_image,num_labeler,p_Z,pr_Alpha,pr_Beta,image_label_T):
    pr_p_z = np.array(p_Z)
    p_Z = pfun(p_Z,pr_Alpha,pr_Beta,num_image,num_labeler,label_arr)
    rate = 0.0001
    accure_list=[0.68]
    ephc_list=[0]
    # print(pr_p_z)
    for ephc in range(200):
        Beta_gard = getbeta(p_Z,label_arr,num_image,num_labeler,pr_Alpha,pr_Beta)
        Alpha_gard = getalpha(p_Z,label_arr,num_image,num_labeler,pr_Alpha,pr_Beta)
        pr_Alpha = pr_Alpha+rate*Alpha_gard
        pr_Beta = pr_Beta+rate*Beta_gard
        p_Z = pfun(p_Z,pr_Alpha,pr_Beta,num_image,num_labeler,label_arr)
        # print(p_Z)
        new_p_z = getp_Z(p_Z,num_image)
        n_accure = get_accuracy(new_p_z, image_label_T)
        accure_list.append(n_accure)
        ephc_list.append(ephc+1)
    ##计算精度
    accure_arr = np.array(accure_list)
    ephc_arr = np.array(ephc_list)
    plt.plot(ephc_arr,accure_arr,color="blue",label="GLAD")
    print("GLAD",n_accure)
    # plt.show()

    # #计算ROC参数
    TP,TN,FP,FN = get_ROC(new_p_z, image_label_T)
    print("GLAD:TP:",TP,"TN:",TN,"FP:",FP,"FN:",FN)

    #绘制ROC曲线
    # pre_label,true_label = get_label(new_p_z, image_label_T,p_Z[1])
    # fpr, tpr, threshold = roc_curve(true_label, pre_label, pos_label=1)  # 返回ROC曲线
    # plt.plot(fpr, tpr, label="GLAD", color="blue")

    return p_Z , pr_Alpha , pr_Beta





